import { motion } from "framer-motion";

export default function ArcReactor({ speaking }: { speaking: boolean }) {
  return (
    <div className="relative flex items-center justify-center" style={{ width: 180, height: 180 }}>
      {/* Outer glow ring */}
      <motion.div
        className="absolute rounded-full border border-cyan-400"
        style={{ width: 180, height: 180 }}
        animate={{ opacity: speaking ? [0.4, 1, 0.4] : [0.2, 0.5, 0.2] }}
        transition={{ duration: speaking ? 0.6 : 2, repeat: Infinity }}
      />

      {/* Rotating ring 1 */}
      <motion.div
        className="absolute rounded-full border border-cyan-500"
        style={{
          width: 160,
          height: 160,
          borderTopColor: "transparent",
          borderRightColor: "transparent",
        }}
        animate={{ rotate: 360 }}
        transition={{ duration: 4, repeat: Infinity, ease: "linear" }}
      />

      {/* Rotating ring 2 - opposite */}
      <motion.div
        className="absolute rounded-full border border-blue-400"
        style={{
          width: 140,
          height: 140,
          borderBottomColor: "transparent",
          borderLeftColor: "transparent",
        }}
        animate={{ rotate: -360 }}
        transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
      />

      {/* Rotating ring 3 */}
      <motion.div
        className="absolute rounded-full border border-cyan-300"
        style={{
          width: 118,
          height: 118,
          borderTopColor: "transparent",
          borderLeftColor: "transparent",
        }}
        animate={{ rotate: 360 }}
        transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
      />

      {/* Inner glow circle */}
      <motion.div
        className="absolute rounded-full"
        style={{
          width: 90,
          height: 90,
          background:
            "radial-gradient(circle, rgba(0,212,255,0.3) 0%, rgba(0,100,255,0.1) 60%, transparent 100%)",
          boxShadow: speaking
            ? "0 0 40px 15px rgba(0,212,255,0.5)"
            : "0 0 20px 8px rgba(0,212,255,0.2)",
        }}
        animate={{
          scale: speaking ? [1, 1.15, 1] : [1, 1.05, 1],
          opacity: speaking ? [0.7, 1, 0.7] : [0.5, 0.8, 0.5],
        }}
        transition={{ duration: speaking ? 0.5 : 2, repeat: Infinity }}
      />

      {/* Center core */}
      <motion.div
        className="relative rounded-full flex items-center justify-center"
        style={{
          width: 60,
          height: 60,
          background:
            "radial-gradient(circle, #00d4ff 0%, #0066ff 50%, #001a4d 100%)",
          boxShadow: "0 0 30px rgba(0,212,255,0.8)",
        }}
        animate={{
          boxShadow: speaking
            ? [
                "0 0 30px rgba(0,212,255,0.8)",
                "0 0 60px rgba(0,212,255,1)",
                "0 0 30px rgba(0,212,255,0.8)",
              ]
            : [
                "0 0 20px rgba(0,212,255,0.5)",
                "0 0 35px rgba(0,212,255,0.7)",
                "0 0 20px rgba(0,212,255,0.5)",
              ],
        }}
        transition={{ duration: speaking ? 0.5 : 2, repeat: Infinity }}
      >
        {/* Hexagonal center pattern */}
        <svg width="36" height="36" viewBox="0 0 36 36">
          <polygon
            points="18,4 30,11 30,25 18,32 6,25 6,11"
            fill="none"
            stroke="rgba(0,212,255,0.9)"
            strokeWidth="1.5"
          />
          <polygon
            points="18,10 25,14 25,22 18,26 11,22 11,14"
            fill="none"
            stroke="rgba(0,212,255,0.6)"
            strokeWidth="1"
          />
          <circle cx="18" cy="18" r="4" fill="rgba(0,212,255,0.9)" />
        </svg>
      </motion.div>

      {/* Audio waveform bars around when speaking */}
      {speaking &&
        Array.from({ length: 12 }).map((_, i) => {
          const angle = (i * 360) / 12;
          const rad = (angle * Math.PI) / 180;
          const r = 95;
          const x = 90 + r * Math.cos(rad);
          const y = 90 + r * Math.sin(rad);
          return (
            <motion.div
              key={i}
              className="absolute bg-cyan-400 rounded-full"
              style={{
                width: 3,
                height: 10,
                left: x,
                top: y,
                transformOrigin: "center",
                transform: `rotate(${angle + 90}deg) translateY(-50%)`,
              }}
              animate={{ scaleY: [0.4, 1.5, 0.4], opacity: [0.4, 1, 0.4] }}
              transition={{
                duration: 0.4 + Math.random() * 0.4,
                repeat: Infinity,
                delay: i * 0.05,
              }}
            />
          );
        })}
    </div>
  );
}
