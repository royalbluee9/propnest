export default function ScanLines() {
  return (
    <div
      className="fixed inset-0 pointer-events-none z-10"
      style={{
        backgroundImage:
          "repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(0,0,0,0.08) 2px, rgba(0,0,0,0.08) 4px)",
        animation: "scanline 8s linear infinite",
      }}
    />
  );
}
