import { motion } from "framer-motion";
import { Bot, User } from "lucide-react";

export type Message = {
  id: string;
  role: "user" | "jarvis";
  content: string;
  timestamp: Date;
};

export default function ChatMessage({ msg }: { msg: Message }) {
  const isJarvis = msg.role === "jarvis";

  return (
    <motion.div
      initial={{ opacity: 0, y: 20, x: isJarvis ? -20 : 20 }}
      animate={{ opacity: 1, y: 0, x: 0 }}
      transition={{ duration: 0.4, ease: "easeOut" }}
      className={`flex gap-3 ${isJarvis ? "flex-row" : "flex-row-reverse"}`}
    >
      {/* Avatar */}
      <div
        className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center border ${
          isJarvis
            ? "border-cyan-500 bg-cyan-950 shadow-[0_0_10px_rgba(0,212,255,0.4)]"
            : "border-blue-500 bg-blue-950"
        }`}
      >
        {isJarvis ? (
          <Bot size={14} className="text-cyan-400" />
        ) : (
          <User size={14} className="text-blue-400" />
        )}
      </div>

      {/* Bubble */}
      <div className={`max-w-[75%] ${isJarvis ? "items-start" : "items-end"} flex flex-col gap-1`}>
        <div
          className={`relative px-4 py-2.5 rounded-lg text-sm leading-relaxed ${
            isJarvis
              ? "bg-cyan-950/60 border border-cyan-700/50 text-cyan-100 rounded-tl-none"
              : "bg-blue-950/60 border border-blue-700/50 text-blue-100 rounded-tr-none"
          }`}
          style={{
            boxShadow: isJarvis
              ? "0 0 15px rgba(0,212,255,0.1) inset, 0 2px 8px rgba(0,0,0,0.4)"
              : "0 0 15px rgba(0,100,255,0.1) inset, 0 2px 8px rgba(0,0,0,0.4)",
          }}
        >
          {/* Corner accent */}
          <div
            className={`absolute top-0 ${isJarvis ? "left-0" : "right-0"} w-2 h-2 border-t border-l ${
              isJarvis ? "border-cyan-400" : "border-blue-400"
            } ${isJarvis ? "" : "rotate-90"}`}
          />
          <div
            className={`absolute bottom-0 ${isJarvis ? "right-0" : "left-0"} w-2 h-2 border-b border-r ${
              isJarvis ? "border-cyan-700" : "border-blue-700"
            } ${isJarvis ? "" : "rotate-90"}`}
          />

          {isJarvis && (
            <span className="block text-[10px] text-cyan-500 font-mono tracking-widest mb-1 font-bold">
              J.A.R.V.I.S.
            </span>
          )}
          <p className="font-mono text-sm">{msg.content}</p>
        </div>
        <span className="text-[10px] text-cyan-700 font-mono px-1">
          {msg.timestamp.toLocaleTimeString("en-US", {
            hour: "2-digit",
            minute: "2-digit",
            second: "2-digit",
            hour12: false,
          })}
        </span>
      </div>
    </motion.div>
  );
}
