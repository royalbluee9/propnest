import { motion } from "framer-motion";
import { Wifi, Cpu, Shield, Zap } from "lucide-react";
import { useEffect, useState } from "react";

export default function StatusBar() {
  const [cpuUsage, setCpuUsage] = useState(42);
  const [networkPing, setNetworkPing] = useState(12);
  const [time, setTime] = useState(new Date());

  useEffect(() => {
    const interval = setInterval(() => {
      setCpuUsage(Math.floor(30 + Math.random() * 40));
      setNetworkPing(Math.floor(8 + Math.random() * 20));
      setTime(new Date());
    }, 1500);
    return () => clearInterval(interval);
  }, []);

  const timeStr = time.toLocaleTimeString("en-US", {
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false,
  });
  const dateStr = time.toLocaleDateString("en-US", {
    weekday: "short",
    year: "numeric",
    month: "short",
    day: "numeric",
  });

  return (
    <div className="flex items-center justify-between w-full px-4 py-2 text-xs font-mono">
      {/* Left side */}
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-1.5 text-cyan-400">
          <Shield size={12} />
          <span className="text-green-400">SECURE</span>
        </div>
        <div className="flex items-center gap-1.5 text-cyan-400">
          <Wifi size={12} />
          <span>{networkPing}ms</span>
        </div>
        <div className="flex items-center gap-1.5 text-cyan-400">
          <Cpu size={12} />
          <motion.span
            key={cpuUsage}
            animate={{ opacity: [0.5, 1] }}
            transition={{ duration: 0.3 }}
          >
            {cpuUsage}%
          </motion.span>
        </div>
      </div>

      {/* Center - system name */}
      <div className="flex flex-col items-center">
        <span className="text-cyan-300 tracking-[0.3em] text-xs font-bold">
          J.A.R.V.I.S.
        </span>
        <span className="text-cyan-600 tracking-widest text-[9px]">
          JUST A RATHER VERY INTELLIGENT SYSTEM
        </span>
      </div>

      {/* Right side */}
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-1.5 text-cyan-400">
          <Zap size={12} />
          <span className="text-green-400">ONLINE</span>
        </div>
        <div className="text-cyan-400 flex flex-col items-end">
          <span className="text-cyan-200">{timeStr}</span>
          <span className="text-cyan-600 text-[9px]">{dateStr}</span>
        </div>
      </div>
    </div>
  );
}
