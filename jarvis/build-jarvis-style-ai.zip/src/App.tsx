import { useState, useRef, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Send, Mic, MicOff, Trash2, Volume2, VolumeX } from "lucide-react";
import HexGrid from "./components/HexGrid";
import ArcReactor from "./components/ArcReactor";
import StatusBar from "./components/StatusBar";
import ChatMessage, { Message } from "./components/ChatMessage";
import TypingIndicator from "./components/TypingIndicator";
import SystemStats from "./components/SystemStats";
import QuickActions from "./components/QuickActions";
import ScanLines from "./components/ScanLines";
import { getJarvisResponse } from "./jarvisResponses";

const BOOT_MESSAGES = [
  "Initializing J.A.R.V.I.S. neural core...",
  "Loading quantum encryption protocols...",
  "Calibrating holographic interface...",
  "Running self-diagnostics...",
  "All systems nominal. Welcome.",
];

export default function App() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [speaking, setSpeaking] = useState(false);
  const [voiceEnabled, setVoiceEnabled] = useState(false);
  const [listening, setListening] = useState(false);
  const [booting, setBooting] = useState(true);
  const [bootLine, setBootLine] = useState(0);
  const [bootDone, setBootDone] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const recognitionRef = useRef<any>(null);

  // Boot sequence
  useEffect(() => {
    if (bootLine < BOOT_MESSAGES.length) {
      const t = setTimeout(() => setBootLine((l) => l + 1), 500);
      return () => clearTimeout(t);
    } else {
      const t = setTimeout(() => {
        setBootDone(true);
        setTimeout(() => setBooting(false), 600);
      }, 400);
      return () => clearTimeout(t);
    }
  }, [bootLine]);

  // Initial greeting after boot
  useEffect(() => {
    if (!booting) {
      const t = setTimeout(() => {
        const greeting: Message = {
          id: crypto.randomUUID(),
          role: "jarvis",
          content:
            "All systems operational. I am J.A.R.V.I.S. — Just A Rather Very Intelligent System. How may I assist you today?",
          timestamp: new Date(),
        };
        setMessages([greeting]);
        if (voiceEnabled) speak(greeting.content);
      }, 300);
      return () => clearTimeout(t);
    }
  }, [booting]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isTyping]);

  const speak = (text: string) => {
    if (!voiceEnabled) return;
    window.speechSynthesis.cancel();
    const utter = new SpeechSynthesisUtterance(text);
    utter.rate = 0.95;
    utter.pitch = 0.85;
    utter.volume = 0.9;
    // Try to find a suitable voice
    const voices = window.speechSynthesis.getVoices();
    const preferred = voices.find(
      (v) =>
        v.name.toLowerCase().includes("david") ||
        v.name.toLowerCase().includes("mark") ||
        v.name.toLowerCase().includes("google uk english male") ||
        v.lang === "en-GB"
    );
    if (preferred) utter.voice = preferred;
    utter.onstart = () => setSpeaking(true);
    utter.onend = () => setSpeaking(false);
    utter.onerror = () => setSpeaking(false);
    window.speechSynthesis.speak(utter);
  };

  const sendMessage = useCallback(
    async (text: string) => {
      const trimmed = text.trim();
      if (!trimmed) return;

      const userMsg: Message = {
        id: crypto.randomUUID(),
        role: "user",
        content: trimmed,
        timestamp: new Date(),
      };

      setMessages((prev) => [...prev, userMsg]);
      setInput("");
      setIsTyping(true);

      try {
        const response = await getJarvisResponse(trimmed);
        setIsTyping(false);
        const jarvisMsg: Message = {
          id: crypto.randomUUID(),
          role: "jarvis",
          content: response,
          timestamp: new Date(),
        };
        setMessages((prev) => [...prev, jarvisMsg]);
        speak(response);
      } catch {
        setIsTyping(false);
        const errMsg: Message = {
          id: crypto.randomUUID(),
          role: "jarvis",
          content:
            "I encountered an anomaly in my processing core. Please repeat your query.",
          timestamp: new Date(),
        };
        setMessages((prev) => [...prev, errMsg]);
      }
    },
    [voiceEnabled]
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    sendMessage(input);
  };

  const startListening = () => {
    if (!("webkitSpeechRecognition" in window || "SpeechRecognition" in window)) {
      alert("Voice recognition is not supported in this browser.");
      return;
    }
    const SpeechRecognitionAPI =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    const recognition = new SpeechRecognitionAPI();
    recognition.lang = "en-US";
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;
    recognitionRef.current = recognition;

    recognition.onstart = () => setListening(true);
    recognition.onresult = (e: any) => {
      const transcript = e.results[0][0].transcript;
      setInput(transcript);
      sendMessage(transcript);
    };
    recognition.onend = () => setListening(false);
    recognition.onerror = () => setListening(false);
    recognition.start();
  };

  const stopListening = () => {
    recognitionRef.current?.stop();
    setListening(false);
  };

  const clearChat = () => {
    window.speechSynthesis.cancel();
    setSpeaking(false);
    setMessages([
      {
        id: crypto.randomUUID(),
        role: "jarvis",
        content:
          "Memory banks cleared. Ready for new directives. How may I assist you?",
        timestamp: new Date(),
      },
    ]);
  };

  const toggleVoice = () => {
    if (voiceEnabled) {
      window.speechSynthesis.cancel();
      setSpeaking(false);
    }
    setVoiceEnabled((v) => !v);
  };

  if (booting) {
    return (
      <div
        className="min-h-screen flex flex-col items-center justify-center font-mono"
        style={{ background: "#000a14" }}
      >
        <HexGrid />
        <motion.div
          className="z-10 flex flex-col items-center gap-8"
          animate={{ opacity: bootDone ? 0 : 1 }}
          transition={{ duration: 0.5 }}
        >
          {/* Arc reactor boot animation */}
          <motion.div
            animate={{ scale: [0.8, 1.05, 1], opacity: [0, 1] }}
            transition={{ duration: 1 }}
          >
            <ArcReactor speaking={false} />
          </motion.div>

          <div className="space-y-2 text-left w-80">
            {BOOT_MESSAGES.slice(0, bootLine).map((line, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.3 }}
                className="flex items-center gap-2"
              >
                <span className="text-cyan-400 text-xs">▶</span>
                <span className="text-cyan-300 text-xs tracking-wider">{line}</span>
              </motion.div>
            ))}
            {bootLine < BOOT_MESSAGES.length && (
              <motion.div
                className="text-cyan-500 text-xs"
                animate={{ opacity: [0, 1, 0] }}
                transition={{ duration: 0.6, repeat: Infinity }}
              >
                _
              </motion.div>
            )}
          </div>
        </motion.div>
      </div>
    );
  }

  return (
    <div
      className="min-h-screen flex flex-col font-mono overflow-hidden"
      style={{ background: "#000a14", color: "#e0f7ff" }}
    >
      <HexGrid />
      <ScanLines />

      {/* Top border glow */}
      <div
        className="absolute top-0 left-0 right-0 h-px z-20"
        style={{
          background:
            "linear-gradient(90deg, transparent, rgba(0,212,255,0.8), transparent)",
          boxShadow: "0 0 20px rgba(0,212,255,0.5)",
        }}
      />

      {/* STATUS BAR */}
      <div className="relative z-20 border-b border-cyan-900/50"
        style={{ background: "rgba(0,10,20,0.9)" }}>
        <StatusBar />
      </div>

      {/* MAIN LAYOUT */}
      <div className="relative z-10 flex flex-1 overflow-hidden">
        {/* LEFT SIDEBAR */}
        <motion.div
          initial={{ x: -60, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          transition={{ duration: 0.6, ease: "easeOut" }}
          className="hidden lg:flex flex-col gap-4 w-64 flex-shrink-0 p-4 border-r border-cyan-900/40 overflow-y-auto"
          style={{ background: "rgba(0,8,20,0.8)" }}
        >
          {/* Arc Reactor */}
          <div className="flex flex-col items-center py-4 gap-4">
            <ArcReactor speaking={speaking} />
            <div className="text-center space-y-1">
              <p className="text-cyan-300 text-xs tracking-[0.3em] font-bold">J.A.R.V.I.S.</p>
              <motion.p
                className="text-[10px] tracking-widest"
                animate={{
                  color: speaking
                    ? ["#00d4ff", "#00ff88", "#00d4ff"]
                    : ["#1a5a6a", "#2a7a8a", "#1a5a6a"],
                }}
                transition={{ duration: 1.5, repeat: Infinity }}
              >
                {speaking ? "SPEAKING..." : isTyping ? "PROCESSING..." : "STANDBY"}
              </motion.p>
            </div>
          </div>

          <SystemStats />
          <QuickActions onSelect={(p) => sendMessage(p)} />

          {/* Corner decorations */}
          <div className="mt-auto space-y-2">
            <div className="border border-cyan-900/50 rounded p-2 text-[9px] text-cyan-700 tracking-wider">
              <div className="flex justify-between">
                <span>VERSION</span>
                <span className="text-cyan-500">v7.4.2</span>
              </div>
              <div className="flex justify-between mt-1">
                <span>BUILD</span>
                <span className="text-cyan-500">STARK-2025</span>
              </div>
              <div className="flex justify-between mt-1">
                <span>STATUS</span>
                <span className="text-green-500">OPTIMAL</span>
              </div>
            </div>
          </div>
        </motion.div>

        {/* CHAT AREA */}
        <div className="flex flex-1 flex-col overflow-hidden">
          {/* Corner decorative elements */}
          <div className="absolute top-16 left-64 w-6 h-6 border-t border-l border-cyan-500/40 pointer-events-none z-10 hidden lg:block" />
          <div className="absolute top-16 right-0 w-6 h-6 border-t border-r border-cyan-500/40 pointer-events-none z-10" />

          {/* Messages */}
          <div className="flex-1 overflow-y-auto px-4 py-6 space-y-5 scrollbar-hide">
            <AnimatePresence initial={false}>
              {messages.map((msg) => (
                <ChatMessage key={msg.id} msg={msg} />
              ))}
            </AnimatePresence>

            {isTyping && <TypingIndicator />}
            <div ref={messagesEndRef} />
          </div>

          {/* INPUT AREA */}
          <motion.div
            initial={{ y: 40, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.3 }}
            className="border-t border-cyan-900/50 p-4"
            style={{ background: "rgba(0,8,20,0.95)" }}
          >
            {/* Top accent line */}
            <div
              className="h-px mb-3 opacity-40"
              style={{
                background:
                  "linear-gradient(90deg, transparent, rgba(0,212,255,0.8), transparent)",
              }}
            />

            <form onSubmit={handleSubmit} className="flex items-center gap-3">
              {/* Mic button */}
              <motion.button
                type="button"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={listening ? stopListening : startListening}
                className={`flex-shrink-0 w-10 h-10 rounded-full border flex items-center justify-center transition-all ${
                  listening
                    ? "border-red-500 bg-red-950/50 text-red-400 shadow-[0_0_15px_rgba(255,0,0,0.3)]"
                    : "border-cyan-700 bg-cyan-950/30 text-cyan-500 hover:border-cyan-500"
                }`}
              >
                {listening ? (
                  <motion.div
                    animate={{ scale: [1, 1.2, 1] }}
                    transition={{ duration: 0.6, repeat: Infinity }}
                  >
                    <MicOff size={16} />
                  </motion.div>
                ) : (
                  <Mic size={16} />
                )}
              </motion.button>

              {/* Input field */}
              <div className="flex-1 relative">
                <div
                  className="absolute inset-0 rounded border border-cyan-700/60 pointer-events-none"
                  style={{
                    boxShadow: input
                      ? "0 0 15px rgba(0,212,255,0.15) inset"
                      : "none",
                  }}
                />
                <input
                  ref={inputRef}
                  type="text"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder="Enter command or query..."
                  className="w-full bg-transparent px-4 py-2.5 text-sm text-cyan-200 placeholder-cyan-800 outline-none tracking-wider"
                  disabled={isTyping}
                  autoFocus
                />
                {/* Blinking cursor decoration */}
                <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center gap-1">
                  <motion.div
                    className="w-0.5 h-4 bg-cyan-500"
                    animate={{ opacity: [1, 0, 1] }}
                    transition={{ duration: 1, repeat: Infinity }}
                  />
                </div>
              </div>

              {/* Voice toggle */}
              <motion.button
                type="button"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={toggleVoice}
                className={`flex-shrink-0 w-10 h-10 rounded-full border flex items-center justify-center transition-all ${
                  voiceEnabled
                    ? "border-cyan-500 bg-cyan-950/50 text-cyan-400 shadow-[0_0_10px_rgba(0,212,255,0.2)]"
                    : "border-cyan-900 bg-transparent text-cyan-700"
                }`}
                title={voiceEnabled ? "Disable voice" : "Enable voice"}
              >
                {voiceEnabled ? <Volume2 size={16} /> : <VolumeX size={16} />}
              </motion.button>

              {/* Clear chat */}
              <motion.button
                type="button"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={clearChat}
                className="flex-shrink-0 w-10 h-10 rounded-full border border-cyan-900 bg-transparent text-cyan-700 hover:text-cyan-500 hover:border-cyan-700 flex items-center justify-center transition-all"
                title="Clear chat"
              >
                <Trash2 size={16} />
              </motion.button>

              {/* Send button */}
              <motion.button
                type="submit"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                disabled={!input.trim() || isTyping}
                className="flex-shrink-0 w-10 h-10 rounded-full border border-cyan-500 bg-cyan-950/50 text-cyan-400 flex items-center justify-center transition-all disabled:opacity-30 disabled:cursor-not-allowed"
                style={{
                  boxShadow: input.trim()
                    ? "0 0 15px rgba(0,212,255,0.3)"
                    : "none",
                }}
              >
                <Send size={16} />
              </motion.button>
            </form>

            <div className="flex items-center justify-between mt-3 text-[10px] text-cyan-800 tracking-widest">
              <span>QUANTUM ENCRYPTED • END-TO-END SECURE</span>
              <span className="text-cyan-700">
                {messages.length} LOG ENTRIES
              </span>
            </div>
          </motion.div>
        </div>

        {/* RIGHT SIDEBAR - decorative HUD panels */}
        <motion.div
          initial={{ x: 60, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          transition={{ duration: 0.6, ease: "easeOut" }}
          className="hidden xl:flex flex-col gap-4 w-56 flex-shrink-0 p-4 border-l border-cyan-900/40 overflow-y-auto"
          style={{ background: "rgba(0,8,20,0.8)" }}
        >
          {/* Radar / circular display */}
          <RadarDisplay />
          <ActivityLog messages={messages} />
          <NetworkStatus />
        </motion.div>
      </div>

      {/* Bottom border glow */}
      <div
        className="absolute bottom-0 left-0 right-0 h-px z-20"
        style={{
          background:
            "linear-gradient(90deg, transparent, rgba(0,212,255,0.5), transparent)",
        }}
      />
    </div>
  );
}

/* ───────── Right sidebar sub-components ───────── */
function RadarDisplay() {
  return (
    <div
      className="border border-cyan-800/50 rounded-lg p-3"
      style={{ background: "rgba(0,20,40,0.8)" }}
    >
      <div className="flex items-center gap-2 mb-3">
        <div className="w-1.5 h-1.5 rounded-full bg-cyan-400 shadow-[0_0_6px_rgba(0,212,255,0.8)]" />
        <span className="text-[10px] tracking-[0.2em] text-cyan-500">RADAR</span>
      </div>
      <div className="relative flex items-center justify-center" style={{ height: 120 }}>
        {[40, 30, 20, 10].map((r) => (
          <div
            key={r}
            className="absolute rounded-full border border-cyan-900/60"
            style={{ width: r * 2, height: r * 2 }}
          />
        ))}
        {/* Rotating sweep */}
        <motion.div
          className="absolute"
          style={{
            width: 80,
            height: 80,
            transformOrigin: "center",
          }}
          animate={{ rotate: 360 }}
          transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
        >
          <div
            style={{
              position: "absolute",
              top: "50%",
              left: "50%",
              width: 40,
              height: 1,
              transformOrigin: "left center",
              background:
                "linear-gradient(90deg, rgba(0,212,255,0.8), transparent)",
            }}
          />
        </motion.div>
        {/* Blips */}
        {[
          { x: 55, y: 35, delay: 0 },
          { x: 70, y: 65, delay: 0.5 },
          { x: 30, y: 70, delay: 1 },
        ].map((b, i) => (
          <motion.div
            key={i}
            className="absolute w-1.5 h-1.5 rounded-full bg-cyan-400"
            style={{ left: b.x, top: b.y }}
            animate={{ opacity: [0, 1, 0], scale: [0.5, 1.5, 0.5] }}
            transition={{
              duration: 2,
              repeat: Infinity,
              delay: b.delay,
              ease: "easeInOut",
            }}
          />
        ))}
        {/* Center cross */}
        <div className="absolute w-px h-4 bg-cyan-600" />
        <div className="absolute h-px w-4 bg-cyan-600" />
      </div>
    </div>
  );
}

function ActivityLog({ messages }: { messages: Message[] }) {
  const recent = messages.slice(-5).reverse();
  return (
    <div
      className="border border-cyan-800/50 rounded-lg p-3 flex-1"
      style={{ background: "rgba(0,20,40,0.8)" }}
    >
      <div className="flex items-center gap-2 mb-3">
        <div className="w-1.5 h-1.5 rounded-full bg-green-400 shadow-[0_0_6px_rgba(0,255,100,0.8)]" />
        <span className="text-[10px] tracking-[0.2em] text-cyan-500">
          ACTIVITY
        </span>
      </div>
      <div className="space-y-2">
        {recent.length === 0 ? (
          <p className="text-[10px] text-cyan-800">Awaiting input...</p>
        ) : (
          recent.map((m) => (
            <motion.div
              key={m.id}
              initial={{ opacity: 0, x: 10 }}
              animate={{ opacity: 1, x: 0 }}
              className="flex items-start gap-1.5"
            >
              <span
                className={`text-[8px] mt-0.5 font-bold ${
                  m.role === "jarvis" ? "text-cyan-500" : "text-blue-400"
                }`}
              >
                {m.role === "jarvis" ? "AI" : "USR"}
              </span>
              <p className="text-[9px] text-cyan-700 leading-tight line-clamp-2">
                {m.content.substring(0, 60)}...
              </p>
            </motion.div>
          ))
        )}
      </div>
    </div>
  );
}

function NetworkStatus() {
  const [packets, setPackets] = useState(
    Array.from({ length: 8 }, () => Math.random())
  );

  useEffect(() => {
    const t = setInterval(() => {
      setPackets(Array.from({ length: 8 }, () => Math.random()));
    }, 1200);
    return () => clearInterval(t);
  }, []);

  return (
    <div
      className="border border-cyan-800/50 rounded-lg p-3"
      style={{ background: "rgba(0,20,40,0.8)" }}
    >
      <div className="flex items-center gap-2 mb-3">
        <div className="w-1.5 h-1.5 rounded-full bg-purple-400 shadow-[0_0_6px_rgba(180,0,255,0.8)]" />
        <span className="text-[10px] tracking-[0.2em] text-cyan-500">
          NETWORK
        </span>
      </div>
      <div className="flex items-end gap-1 h-12">
        {packets.map((v, i) => (
          <motion.div
            key={i}
            className="flex-1 rounded-sm bg-cyan-500"
            animate={{ height: `${v * 100}%`, opacity: 0.4 + v * 0.6 }}
            transition={{ duration: 0.5, ease: "easeInOut" }}
            style={{ minHeight: 2 }}
          />
        ))}
      </div>
      <div className="flex justify-between mt-2 text-[9px] text-cyan-700">
        <span>TX: 2.4MB/s</span>
        <span>RX: 1.8MB/s</span>
      </div>
    </div>
  );
}
