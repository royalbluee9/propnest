import { motion } from "framer-motion";
import { useEffect, useState } from "react";

const SYSTEMS = [
  { label: "NEURAL NET", color: "cyan" },
  { label: "QUANTUM CORE", color: "blue" },
  { label: "POWER GRID", color: "green" },
  { label: "FIREWALL", color: "purple" },
];

function Bar({ label, color }: { label: string; color: string }) {
  const [val, setVal] = useState(Math.floor(60 + Math.random() * 35));

  useEffect(() => {
    const t = setInterval(() => {
      setVal(Math.floor(55 + Math.random() * 40));
    }, 2000 + Math.random() * 1000);
    return () => clearInterval(t);
  }, []);

  const colorMap: Record<string, string> = {
    cyan: "bg-cyan-400 shadow-cyan-400",
    blue: "bg-blue-400 shadow-blue-400",
    green: "bg-green-400 shadow-green-400",
    purple: "bg-purple-400 shadow-purple-400",
  };

  const textMap: Record<string, string> = {
    cyan: "text-cyan-400",
    blue: "text-blue-400",
    green: "text-green-400",
    purple: "text-purple-400",
  };

  const borderMap: Record<string, string> = {
    cyan: "border-cyan-800",
    blue: "border-blue-800",
    green: "border-green-800",
    purple: "border-purple-800",
  };

  return (
    <div className="space-y-1">
      <div className="flex justify-between items-center">
        <span className={`text-[10px] font-mono tracking-widest ${textMap[color]}`}>
          {label}
        </span>
        <motion.span
          key={val}
          className={`text-[10px] font-mono font-bold ${textMap[color]}`}
          animate={{ opacity: [0.5, 1] }}
          transition={{ duration: 0.3 }}
        >
          {val}%
        </motion.span>
      </div>
      <div className={`h-1.5 rounded-full bg-gray-900 border ${borderMap[color]} overflow-hidden`}>
        <motion.div
          className={`h-full rounded-full ${colorMap[color]} shadow-sm`}
          animate={{ width: `${val}%` }}
          transition={{ duration: 0.8, ease: "easeInOut" }}
        />
      </div>
    </div>
  );
}

export default function SystemStats() {
  return (
    <div
      className="border border-cyan-800/50 rounded-lg p-3 space-y-3"
      style={{
        background:
          "linear-gradient(135deg, rgba(0,20,40,0.8) 0%, rgba(0,10,30,0.9) 100%)",
        boxShadow: "0 0 20px rgba(0,212,255,0.05) inset",
      }}
    >
      <div className="flex items-center gap-2 mb-2">
        <div className="w-1.5 h-1.5 rounded-full bg-cyan-400 shadow-[0_0_6px_rgba(0,212,255,0.8)]" />
        <span className="text-[10px] font-mono tracking-[0.2em] text-cyan-500">
          SYSTEM MONITOR
        </span>
      </div>
      {SYSTEMS.map((s) => (
        <Bar key={s.label} label={s.label} color={s.color} />
      ))}
    </div>
  );
}
