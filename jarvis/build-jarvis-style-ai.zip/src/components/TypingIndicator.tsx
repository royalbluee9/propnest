import { motion } from "framer-motion";

export default function TypingIndicator() {
  return (
    <div className="flex gap-3 flex-row">
      {/* Avatar */}
      <div className="flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center border border-cyan-500 bg-cyan-950 shadow-[0_0_10px_rgba(0,212,255,0.4)]">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none">
          <circle cx="12" cy="12" r="10" stroke="rgba(0,212,255,0.8)" strokeWidth="2" />
          <circle cx="12" cy="12" r="5" fill="rgba(0,212,255,0.5)" />
        </svg>
      </div>

      <div className="bg-cyan-950/60 border border-cyan-700/50 px-4 py-3 rounded-lg rounded-tl-none">
        <span className="block text-[10px] text-cyan-500 font-mono tracking-widest mb-2 font-bold">
          J.A.R.V.I.S. PROCESSING
        </span>
        <div className="flex gap-1.5 items-center h-4">
          {[0, 1, 2, 3, 4].map((i) => (
            <motion.div
              key={i}
              className="bg-cyan-400 rounded-full"
              style={{ width: 3, height: 3 }}
              animate={{ scaleY: [1, 3, 1], opacity: [0.4, 1, 0.4] }}
              transition={{
                duration: 0.8,
                repeat: Infinity,
                delay: i * 0.15,
                ease: "easeInOut",
              }}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
