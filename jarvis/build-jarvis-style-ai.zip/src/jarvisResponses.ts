const JARVIS_RESPONSES: Record<string, string[]> = {
  greeting: [
    "Good day. All systems are operational and running at optimal efficiency. How may I assist you?",
    "Online and ready. Neural networks initialized. Awaiting your command.",
    "Systems nominal. I'm fully operational. What can I do for you today?",
  ],
  identity: [
    "I am J.A.R.V.I.S. — Just A Rather Very Intelligent System. I was designed to assist, analyze, and execute with precision.",
    "I'm your personal AI assistant — an advanced intelligence system built to augment your capabilities.",
  ],
  capabilities: [
    "I can analyze data, write and debug code, research topics, generate creative content, solve mathematical problems, and provide strategic insights — all in real time.",
    "My capabilities include natural language processing, data analysis, code generation, creative writing, problem-solving, and much more. Simply ask.",
  ],
  analyze: [
    "Initiating deep analysis protocol... Processing all available data vectors. Key insight: Complex systems benefit from iterative refinement. I recommend a phased approach with measurable checkpoints.",
    "Analysis complete. Current data patterns suggest three primary vectors of opportunity. Prioritize the one with lowest friction and highest leverage. Shall I elaborate?",
    "Running multi-layer analysis... The critical factors are: resource allocation, risk assessment, and timeline feasibility. I recommend starting with the highest-impact, lowest-risk initiative.",
  ],
  code: [
    "Accessing code generation module... I recommend starting with a clean architecture: separate concerns, use meaningful names, write tests first. What language and framework are you targeting?",
    "Code initialized. Best practices: SOLID principles, DRY code, and comprehensive documentation. I can generate boilerplate, debug existing code, or optimize for performance. What's the objective?",
    "Compiling solution... Here's my recommendation: modular design with clear interfaces, async operations where beneficial, and proper error handling. Specify your requirements and I'll draft it.",
  ],
  research: [
    "Scanning knowledge databases... AI advancements in 2025 include multimodal foundation models, agentic AI systems, neuromorphic computing, and quantum-enhanced machine learning. Shall I detail any of these?",
    "Research module active. Key findings: The intersection of AI and human cognition is evolving rapidly. Transformers, diffusion models, and reinforcement learning from human feedback are the dominant paradigms.",
    "Database query complete. Notable breakthroughs include: large-scale reasoning models, protein structure prediction, autonomous systems, and AI-driven drug discovery. Which area requires deeper analysis?",
  ],
  ideas: [
    "Generating innovation proposals... 1) AI-powered predictive health monitoring. 2) Quantum-secured blockchain identity. 3) Adaptive AR workspace overlays. 4) Neural interface productivity tools. 5) Decentralized autonomous knowledge networks. Shall I expand on any?",
    "Creativity module activated. Five high-potential concepts: 1) Smart city optimization AI. 2) Personalized learning neural networks. 3) Climate modeling with federated AI. 4) Holographic telepresence platforms. 5) Autonomous creative collaboration systems.",
  ],
  summarize: [
    "Summary module engaged. Effective summarization requires: identifying core thesis, extracting key supporting points, noting critical data, and distilling conclusions. Provide the content and I'll handle the rest.",
    "Ready to summarize. I'll extract the essential information, eliminate redundancy, and deliver a concise, actionable overview. What would you like me to summarize?",
  ],
  plan: [
    "Strategic planning initiated. Phase 1: Define clear objectives and success metrics. Phase 2: Identify resources and constraints. Phase 3: Map execution timeline. Phase 4: Build contingency protocols. Phase 5: Iterate and optimize. Ready to detail each phase?",
    "Action plan framework activated. To achieve any major goal: Start with the end in mind, work backwards to identify milestones, allocate resources strategically, and build in review cycles. What is the specific goal?",
  ],
  help: [
    "I can assist with analysis, coding, research, creative ideation, summarization, and strategic planning. Simply type your request or use the Quick Commands panel on the left.",
    "Command reference: Ask me to analyze, code, research, brainstorm, summarize, or plan. I also respond to direct questions and conversational input.",
  ],
  weather: [
    "I'm currently operating in local mode without external API connections. However, I can help you understand weather patterns, atmospheric science, or climate modeling — shall I?",
    "External data feeds are in standby mode. For real-time weather data, you'd need to connect me to a weather API endpoint. In the meantime, I can discuss meteorological patterns.",
  ],
  time: [
    `The current timestamp is displayed in the system header above. Is there something specific about time management or scheduling I can help you with?`,
  ],
  math: [
    "Mathematical computation module ready. I can handle algebra, calculus, statistics, linear algebra, number theory, and more. What's the problem?",
    "Numbers are my native language. From basic arithmetic to complex differential equations, I process them with precision. State the problem.",
  ],
  fallback: [
    "Understood. Processing your query through my neural network... I've noted your request and I'm formulating the optimal response. Could you provide additional context so I can deliver a more precise answer?",
    "Query received and logged. My analysis suggests multiple possible interpretations. To ensure accuracy, I'd recommend clarifying your primary objective. What outcome are you looking for?",
    "Acknowledged. I'm cross-referencing multiple knowledge domains to formulate a comprehensive response. This falls into an interesting area — let me offer a multi-faceted perspective.",
    "Interesting request. Running pattern recognition... Based on my analysis, here's the most actionable approach: break it into smaller components, tackle the highest-leverage piece first, and iterate rapidly.",
    "Processing... My recommendation is to approach this systematically. Define the problem clearly, gather relevant data, generate options, evaluate trade-offs, and implement the optimal solution. Shall I assist with any specific step?",
  ],
};

function detectIntent(input: string): string {
  const lower = input.toLowerCase();

  if (/hello|hi |hey|good (morning|afternoon|evening|day)|greet/.test(lower))
    return "greeting";
  if (/who are you|what are you|your name|jarvis|j\.a\.r\.v\.i\.s/.test(lower))
    return "identity";
  if (/what can you do|capabilities|help me|features|functions/.test(lower))
    return "capabilities";
  if (/analyz|assessment|evaluate|review|examine/.test(lower))
    return "analyze";
  if (/code|program|script|function|debug|develop|software/.test(lower))
    return "code";
  if (/research|find|discover|learn about|tell me about|latest|news/.test(lower))
    return "research";
  if (/idea|innovat|creative|suggest|brainstorm|startup/.test(lower))
    return "ideas";
  if (/summar|brief|tldr|overview|condense/.test(lower))
    return "summarize";
  if (/plan|strategy|roadmap|action|goal|achieve|steps/.test(lower))
    return "plan";
  if (/help|command|what can|assist/.test(lower))
    return "help";
  if (/weather|temperature|forecast|rain|sunny/.test(lower))
    return "weather";
  if (/time|date|clock|when/.test(lower))
    return "time";
  if (/math|calculat|number|equation|formula|solve/.test(lower))
    return "math";
  return "fallback";
}

function pick<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

export function getJarvisResponse(input: string): Promise<string> {
  const intent = detectIntent(input);
  const responses = JARVIS_RESPONSES[intent] || JARVIS_RESPONSES.fallback;
  const delay = 800 + Math.random() * 1200;
  return new Promise((resolve) => setTimeout(() => resolve(pick(responses)), delay));
}
