import { motion } from "framer-motion";
import {
  Brain,
  Code2,
  Globe,
  Lightbulb,
  MessageSquare,
  Rocket,
} from "lucide-react";

const ACTIONS = [
  { icon: Brain, label: "Analyze", prompt: "Analyze the current situation and give me a strategic overview." },
  { icon: Code2, label: "Code", prompt: "Help me write clean, efficient code for a new project." },
  { icon: Globe, label: "Research", prompt: "Research the latest advancements in artificial intelligence." },
  { icon: Lightbulb, label: "Ideas", prompt: "Give me 5 innovative ideas for a tech startup." },
  { icon: MessageSquare, label: "Summarize", prompt: "Summarize the key points of any given topic clearly." },
  { icon: Rocket, label: "Plan", prompt: "Create a detailed action plan for achieving a major goal." },
];

export default function QuickActions({
  onSelect,
}: {
  onSelect: (prompt: string) => void;
}) {
  return (
    <div
      className="border border-cyan-800/50 rounded-lg p-3"
      style={{
        background:
          "linear-gradient(135deg, rgba(0,20,40,0.8) 0%, rgba(0,10,30,0.9) 100%)",
      }}
    >
      <div className="flex items-center gap-2 mb-3">
        <div className="w-1.5 h-1.5 rounded-full bg-cyan-400 shadow-[0_0_6px_rgba(0,212,255,0.8)]" />
        <span className="text-[10px] font-mono tracking-[0.2em] text-cyan-500">
          QUICK COMMANDS
        </span>
      </div>
      <div className="grid grid-cols-2 gap-2">
        {ACTIONS.map((action) => {
          const Icon = action.icon;
          return (
            <motion.button
              key={action.label}
              whileHover={{ scale: 1.02, borderColor: "rgba(0,212,255,0.6)" }}
              whileTap={{ scale: 0.97 }}
              onClick={() => onSelect(action.prompt)}
              className="flex items-center gap-2 px-2.5 py-2 rounded border border-cyan-900/60 bg-cyan-950/30 text-left transition-all"
              style={{ boxShadow: "0 0 8px rgba(0,212,255,0.05) inset" }}
            >
              <Icon size={12} className="text-cyan-400 flex-shrink-0" />
              <span className="text-[10px] font-mono text-cyan-300 tracking-wider">
                {action.label}
              </span>
            </motion.button>
          );
        })}
      </div>
    </div>
  );
}
